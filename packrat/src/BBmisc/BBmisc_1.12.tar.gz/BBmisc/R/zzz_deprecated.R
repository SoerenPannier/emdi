#FIXME: remove

#' Deprecated function. Do not use!
#'
#' @param df No text
#' @param chars.as.factor No text
#' @param factors.as.char No text
#' @param ints.as.num No text
#' @param logicals.as.factor No text
#' @param x No text
#' @param num.format No text
#' @param clip.len No text
#'
#' @name deprecated
#' @rdname deprecated
NULL

#' @export
#' @rdname deprecated
convertDfCols = convertDataFrameCols

#' @export
#' @rdname deprecated
listToShortString = convertToShortString
