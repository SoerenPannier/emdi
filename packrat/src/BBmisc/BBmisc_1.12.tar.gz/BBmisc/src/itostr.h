#ifndef BBMISC_ITOSTR_H_
#define BBMISC_ITOSTR_H_

#include <R.h>
#include <Rinternals.h>
#include <Rdefines.h>

SEXP itostr(SEXP, SEXP);

#endif
