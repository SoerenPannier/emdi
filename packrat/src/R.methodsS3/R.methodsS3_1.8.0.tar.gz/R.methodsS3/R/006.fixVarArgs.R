# Added '...' to some base functions. These will later be
# turned into default functions by setMethodS3().
