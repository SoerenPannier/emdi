library("R.rsp")

s <- RspString()
print(s)

d <- RspDocument()
print(d)
