#' @import methods
#' @importFrom utils object.size globalVariables
#' @importFrom magrittr %>% %<>% equals inset
NULL

globalVariables(".")
