## ---- eval=FALSE---------------------------------------------------------
#  vignette("aoosClasses", "aoos")

## ---- eval=FALSE---------------------------------------------------------
#  vignette("referenceClasses", "aoos")

## ---- eval=FALSE---------------------------------------------------------
#  vignette("retListClasses", "aoos")

## ---- eval=FALSE---------------------------------------------------------
#  vignette("S4SyntacticSugar", "aoos")

