library(testthat)
library(aoos)

test_check("aoos")
