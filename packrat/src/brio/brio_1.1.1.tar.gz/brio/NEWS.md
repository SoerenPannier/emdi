# brio 1.1.1

* `file_line_endings()` now works as expected on ARM systems (#8)

# brio 1.1.0

* New `write_file()` function to write an entire file (#7)

* `read_lines()` no longer leaks file handles.

* Added a `NEWS.md` file to track changes to the package.

# brio 1.0.0

* Initial release
