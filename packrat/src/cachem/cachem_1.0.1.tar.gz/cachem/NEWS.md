cachem 1.0.1
============

* Fixed function delcaration of `C_validate_key`.

cachem 1.0.0
============

* First CRAN release.
