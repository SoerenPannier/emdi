#ifndef CHECKMATE_IS_SORTED_H_
#define CHECKMATE_IS_SORTED_H_

#include <R.h>
#include <Rinternals.h>
#include <Rversion.h>

Rboolean is_sorted(SEXP x);

#endif
