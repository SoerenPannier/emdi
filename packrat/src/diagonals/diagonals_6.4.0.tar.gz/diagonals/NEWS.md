diagonals 6.4.0
===================

* redo documentation
* add ORCID
* switch from Travis to GitHub Actions
* various URL updates


diagonals 5.3.0
===================

* add rmarkdown dependency


diagonals 5.2.0
===================

* sync version number with gvc and decompr
* switch from travic to GitHub Actions
* redo documentation


diagonals 1.0.1
===================

* remove matricise


diagonals 1.0.1
===================

* remove matricise


diagonals 1.0.0
===================

* stable release

* updated documentation


diagonals 0.4.0
===================

* various small fixes


diagonals 0.3.0
===================

* replace all previous functions with fatdiag

* add fatdig <- function


diagonals 0.2.0
===================

* add support for replacement other than 0 (zero)

* break out rectangles to separate functions: rectangle_matrix() and minus_rectangle_matrix()


diagonals 0.1.0
===================

* block_matrix(): for extracting block diagonals

* minus_block_matrix(): for dropping block diagonals

* add support for non-square matrices
