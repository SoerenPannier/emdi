library(testthat)
library(diagonals)

test_check("diagonals")
