library(testthat)
library(formula.tools)

test_check("formula.tools")
