# detect odd/even integers
odd <- function(x) x %% 2 == 1
even <- function(x) x %% 2 == 0
