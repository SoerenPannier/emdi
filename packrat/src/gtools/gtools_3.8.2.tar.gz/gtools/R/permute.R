permute <- function(x) sample( x, size=length(x), replace=FALSE )
