# Dummy until implemented in testthat
verify_errors <- identity
