library(testthat)
library(memoise)

test_check("memoise")
