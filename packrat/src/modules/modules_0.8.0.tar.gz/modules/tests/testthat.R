library("modules")

if (requireNamespace("testthat", quietly = TRUE))
  testthat::test_check("modules")
