library(testthat)
library(openxlsx)

test_check("openxlsx")
