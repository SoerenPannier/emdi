library(testthat)
library(operator.tools)

test_check("operator.tools")
