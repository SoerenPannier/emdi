# output test

    Code
      rowidformat(3)
    Output
      <pillar>
       
      1
      2
      3
    Code
      rowidformat(12, has_title_row = TRUE, has_star = TRUE)
    Output
      <pillar>
        
       *
       1
       2
       3
       4
       5
       6
       7
       8
       9
      10
      11
      12

