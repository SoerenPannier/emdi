std::vector<int > get_dims( std::vector<int > dim);
std::vector<std::vector< double > > get_aggregates(std::vector<std::vector< double > > data, std::vector<int> dim);
std::vector<std::vector< double > > aggregate(std::vector<std::vector< double > > data, std::vector<int> dim, bool narm, int fun);
