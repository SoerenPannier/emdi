# Authors: Robert J. Hijmans 
# Date : October 2008
# Version 0.9
# Licence GPL v3
