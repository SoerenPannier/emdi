static r_obj* hash_file_impl(void* p_data);
