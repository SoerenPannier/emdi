r_obj* str_unserialise_unicode(r_obj* r_string);
