# useful warnings

    [<text>:3] @includeRmd Can't find Rmd 'path'

---

    [<text>:3] @includeRmd failed to evaluate Rmd
    Caused by error:
    ! Error

