#' @export
f <- function(x) x


#' @evalNamespace "export(g)"
g <- function() 1
