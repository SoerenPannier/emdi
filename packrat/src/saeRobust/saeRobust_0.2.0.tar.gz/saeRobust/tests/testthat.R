library("testthat")
library("saeRobust")

test_check("saeRobust")
