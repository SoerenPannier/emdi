myDataGeneration <- function(size, ...) {
    # computations
}