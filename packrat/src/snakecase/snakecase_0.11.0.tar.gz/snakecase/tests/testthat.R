library("testthat")
library("tibble")
library("snakecase")


test_check("snakecase")