# after must be integer or character

    Code
      (expect_error(append_df(df1, df2, after = 1)))
    Output
      <simpleError: `after` must be character or integer>

