# errors on negative weights

    Code
      (expect_error(uncount(df, w)))
    Output
      <error/rlang_error>
      all elements of `weights` must be >= 0

