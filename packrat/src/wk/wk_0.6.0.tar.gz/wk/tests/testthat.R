library(testthat)
library(wk)

test_check("wk")
